import numpy as np
import tensorflow as tf
import os
import pandas as pd
from h5py import run_tests
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, ConfusionMatrixDisplay
import matplotlib.pyplot as plt
import argparse
import pickle
import sys
import glob
import warnings
warnings.filterwarnings("ignore", message="Skipping variable loading for optimizer 'adam'")


# Set random seed for reproducibility
np.random.seed(42)
tf.random.set_seed(42)

# Evaluation functionality
def run_evaluation(model_path,max_sequence_length = 200):

    if not model_path.endswith(".keras"):
        model_path += ".keras"

    if not os.path.exists(model_path):
        print(f"Error: Model file '{model_path}' does not exist.")
        return

    default_data_path = "training_data"
    X,y = load_data_from_path(default_data_path,max_length=max_sequence_length)

    X_train, X_temp, y_train, y_temp = train_test_split(X, y, test_size=0.3, random_state=42)

    X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.5, random_state=42)

    input_shape = (max_sequence_length, 3)
    num_classes = 10
    model = build_model(input_shape, num_classes)
    model.compile(optimizer=tf.keras.optimizers.Adam(),
                  loss=tf.keras.losses.SparseCategoricalCrossentropy(),
                  metrics=['accuracy'])

    print(f"Loading model from {model_path}...")
    model = tf.keras.models.load_model(model_path)

    print("Evaluating on the test dataset...")
    loss, accuracy = model.evaluate(X_test, y_test, verbose=1)
    print(f"Test Loss: {loss:.4f}, Test Accuracy: {accuracy:.4f}")

    # Get predictions for confusion matrix
    print("Generating predictions for the confusion matrix...")
    y_pred = model.predict(X_test)
    y_pred = np.argmax(y_pred, axis=1)

    print_classification_report(y_test, y_pred)
    # Plot the confusion matrix
    print("Displaying confusion matrix...")
    plot_confusion_matrix(y_test, y_pred)

# Visualization functionality
def run_visualization(model_name):
    """
        Visualizes training and validation metrics from the history file """
    if os.path.splitext(model_name)[1]:
        raise ValueError("Please provide the model name without an extension.")

        # Construct the history file path
    history_file = f"{model_name}.keras_history.pkl"

    if not os.path.exists(history_file):
        print(f"Error: Model history file '{history_file}' does not exist.")
        return

    print(f"Loading training history from {history_file}...")
    with open(history_file, "rb") as f:
        history = pickle.load(f)

    # Call functions to plot training and validation metrics
    print("Visualizing training and validation loss...")
    plot_training_history(history)  # Plot training/validation loss and accuracy

# Prediction functionality
def run_prediction(folder_path, max_sequence_length):
    """
    Runs predictions on a folder of test samples.

    Parameters:
    - model_path (str): Path to the trained model.
    - folder_path (str): Path to the folder containing test sample CSV files.
    - max_sequence_length (int): Maximum sequence length for preprocessing.
    """

    if not os.path.exists(folder_path):
        print(f"Error: Sample folder '{folder_path}' does not exist.")
        return

    print(f"Running predictions on samples in {folder_path}...")
    for file in os.listdir(folder_path):
        if file.endswith(".csv"):
            sample_path = os.path.join(folder_path, file)
            sample = pd.read_csv(sample_path, header=None).values
            # Make prediction
            predicted_label = digit_classify(sample,max_sequence_length=max_sequence_length)
            print(f"File: {file}, Predicted Class: {predicted_label}")


# Cleanup functionality
def run_cleanup(model_path=None):
    """
    Deletes specified model file or all `.keras` model files if no specific file is provided.

    Parameters:
    - model_path (str): Base name of the model file to delete (optional, no extension required).
    """
    if model_path:

        if not model_path.endswith(".keras"):
            model_path += ".keras"
            model_history_path = model_path + "_history.pkl"
        # check and delete the specific model file
        if os.path.exists(model_path):
            os.remove(model_path)
            print(f"Deleted model file: {model_path}")
        else:
            print(f"No model file found at {model_path}.")
        if os.path.exists(model_history_path):
            os.remove(model_history_path)
            print(f"Deleted model history file: {model_history_path}")
        else:
            print(f"No model history file found at {model_history_path}.")
    else:
        # Find and delete all `.keras` model files in the current directory
        model_files = glob.glob("*.keras")
        model_histories_files = glob.glob("*.keras_history.pkl")
        if model_files:
            for model_file in model_files:
                os.remove(model_file)
                print(f"Deleted model file: {model_file}")
        else:
            print("No model files found to delete.")

        if model_histories_files:
            for model_history_files in model_histories_files:
                os.remove(model_history_files)
                print(f"Deleted model history file: {model_history_files}")
        else:
            print("No model history files found to delete.")

# Function for preprocessing a single sample
def preprocess_sample(sample, max_length=200):
    """"Normalize each column, pad or truncate to max_length."""
    for i in range(sample.shape[1]):
        sample[:, i] = (sample[:, i] - np.min(sample[:, i])) / (np.max(sample[:, i]) - np.min(sample[:, i]) + 1e-6)
    if sample.shape[0] > max_length:
        sample = sample[:max_length]
    else:
        padding = np.zeros((max_length - sample.shape[0], sample.shape[1]))
        sample = np.vstack((sample, padding))
    return sample

# Function for loading and preprocessing data
def load_data_from_path(data_path, max_length=200):
    """Load and preprocess CSV files from the specified data path."""
    data, labels = [], []
    for root, _, files in os.walk(data_path):
        for file in files:
            if file.endswith('.csv'):
                try:
                    label = int(file.split("_")[1])  # Extract labels from filename
                    sample = pd.read_csv(os.path.join(root, file), header=None).values
                    processed_sample = preprocess_sample(sample, max_length)
                    data.append(processed_sample)
                    labels.append(label)
                except Exception as e:
                    print(f"Error processing file {file}: {e}")
    return np.array(data), np.array(labels)


# Function for building CNN model
def build_model(input_shape, num_classes):
    """Build a CNN for digit classification."""
    model = tf.keras.Sequential([
        tf.keras.layers.Input(shape=input_shape),
        tf.keras.layers.Conv1D(32, kernel_size=3, activation='relu'),
        tf.keras.layers.MaxPooling1D(pool_size=2),
        tf.keras.layers.Conv1D(64, kernel_size=3, activation='relu'),
        tf.keras.layers.GlobalAveragePooling1D(),
        tf.keras.layers.Dense(128, activation='relu'),
        tf.keras.layers.Dense(num_classes, activation='softmax')
    ])
    return model

# Function for custom training loop
def train_model(model, X_train, y_train, X_val, y_val, epochs, batch_size):
    """here we are making custom training loop with accuracy and loos tracking we first make loop for number of epochs and then for training
       and validation and then we will show the results."""
    optimizer = tf.keras.optimizers.Adam()
    loss_fn = tf.keras.losses.SparseCategoricalCrossentropy()

    train_acc_metric = tf.keras.metrics.SparseCategoricalAccuracy()
    val_acc_metric = tf.keras.metrics.SparseCategoricalAccuracy()

    history = {"train_loss": [], "val_loss": [], "train_accuracy": [], "val_accuracy": []}

    for epoch in range(epochs):
        print(f"\nEpoch {epoch + 1}/{epochs}")
        indices = np.arange(X_train.shape[0])
        np.random.shuffle(indices)
        X_train, y_train = X_train[indices], y_train[indices]

        train_loss = 0.0
        val_loss = 0.0

        # Training loop
        for i in range(0, X_train.shape[0], batch_size):
            X_batch, y_batch = X_train[i:i + batch_size], y_train[i:i + batch_size]
            with tf.GradientTape() as tape:
                logits = model(X_batch, training=True)
                loss = loss_fn(y_batch, logits)
            grads = tape.gradient(loss, model.trainable_weights)
            optimizer.apply_gradients(zip(grads, model.trainable_weights))
            train_loss += loss.numpy()
            train_acc_metric.update_state(y_batch, logits)

        # Validation loop
        for i in range(0, X_val.shape[0], batch_size):
            X_val_batch, y_val_batch = X_val[i:i + batch_size], y_val[i:i + batch_size]
            val_logits = model(X_val_batch, training=False)
            val_loss += loss_fn(y_val_batch, val_logits).numpy()
            val_acc_metric.update_state(y_val_batch, val_logits)

        history["train_loss"].append(train_loss / (X_train.shape[0] // batch_size))
        history["val_loss"].append(val_loss / (X_val.shape[0] // batch_size))
        history["train_accuracy"].append(train_acc_metric.result().numpy())
        history["val_accuracy"].append(val_acc_metric.result().numpy())

        print(f"Training Loss: {history['train_loss'][-1]:.4f}, Accuracy: {history['train_accuracy'][-1]:.4f}, "
              f"Validation Loss: {history['val_loss'][-1]:.4f}, Accuracy: {history['val_accuracy'][-1]:.4f}")

        train_acc_metric.reset_state()
        val_acc_metric.reset_state()

    return history

# Function to classify a single sample
def digit_classify(sample, model_path="trained_model.keras", max_sequence_length=200, verbose=0):
    """
    Classifies a single test sample.

    Parameters:
    - sample (np.array): Input data as N x 3 matrix.
    - model_path (str): Path to the trained model. (default: "trained_model.keras")
    - max_sequence_length (int): Maximum sequence length for preprocessing. (default: 200)

    Returns:
    - int: Predicted class label.
    """
    # Check if model exists
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"Error: Model file '{model_path}' does not exist.")

    # Load the model
    model = tf.keras.models.load_model(model_path)

    # Preprocess the sample
    sample = preprocess_sample(sample, max_length=max_sequence_length)
    sample = np.expand_dims(sample, axis=0)

    # Predict the class label
    predictions = model.predict(sample, verbose=0)
    if verbose > 0:
        print(np.argmax(predictions))
    return np.argmax(predictions)

def run_test(sample_path, model_path="trained_model.keras", max_sequence_length=200, verbose=0):
    """
    Loads a sample from a file, preprocesses it, and classifies it using the trained model.

    Parameters:
    - sample_path (str): File path to the test sample (CSV format).
    - model_path (str): Path to the trained model. (default: "trained_model.keras")
    - max_sequence_length (int): Maximum sequence length for preprocessing. (default: 200)
    """
    # Check if sample file exists
    if not os.path.exists(sample_path):
        raise FileNotFoundError(f"Error: Sample file '{sample_path}' does not exist.")

    # Load the sample from file
    sample = pd.read_csv(sample_path, header=None).values

    # Call the standalone digit_classify function
    digit_classify(sample, model_path=model_path, max_sequence_length=max_sequence_length, verbose=verbose)



# Save training history in run_training
def run_training(epochs, batch_size, save_model_path, max_sequence_length, training_data_path):
    if not os.path.exists(training_data_path):
        print(f"Error: Training data directory '{training_data_path}' does not exist.")
        sys.exit(1)  # Exit the script with an error code

    # Load data from the specified path
    print(f"Loading training data from {training_data_path} with max_sequence_length = {max_sequence_length}...")
    X, y = load_data_from_path(training_data_path, max_length=max_sequence_length)
    X_train, X_temp, y_train, y_temp = train_test_split(X, y, test_size=0.3, random_state=42)
    X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.5, random_state=42)
    # Check for extensions
    if os.path.splitext(save_model_path)[1]:
        raise ValueError("Please do not provide a file extension. The model will be saved with the `.keras` extension automatically.")
    save_model_path = f"{save_model_path}.keras"

    # Rebuild model with updated input shape
    input_shape = (max_sequence_length, 3)
    model = build_model(input_shape, num_classes=10)
    model.compile(optimizer=tf.keras.optimizers.Adam(),
                  loss=tf.keras.losses.SparseCategoricalCrossentropy(),
                  metrics=['accuracy'])

    print(f"Starting training for {epochs} epochs with batch size {batch_size}.")
    history = train_model(model, X_train, y_train, X_val, y_val, epochs=epochs, batch_size=batch_size)

    # Save the model
    model.save(save_model_path)
    print(f"Model saved to {save_model_path}.")

    # Save training history
    history_file = f"{save_model_path}_history.pkl"
    with open(history_file, "wb") as f:
        pickle.dump(history, f)
    print(f"Training history saved to {history_file}.")

def plot_training_history(history):

    epochs = range(1, len(history["train_accuracy"]) + 1)

    # Plot Accuracy
    plt.figure()
    plt.plot(epochs, history["train_accuracy"], label="Training Accuracy")
    plt.plot(epochs, history["val_accuracy"], label="Validation Accuracy")
    plt.title("Training and Validation Accuracy")
    plt.xlabel("Epochs")
    plt.ylabel("Accuracy")
    plt.legend()
    plt.show()

def plot_confusion_matrix(y_true, y_pred):
    """
    plot the confusion matrix.
    parameters:
    - y_true: true labels.
    - y_pred: predicted labels.
    """
    cm = confusion_matrix(y_true, y_pred)
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=np.unique(y_true))
    disp.plot(cmap=plt.cm.Blues)
    plt.title("Confusion Matrix")
    plt.show()


def print_classification_report(y_true, y_pred):
    """
    print the classification report.
    parameters:
    - y_true: true labels.
    - y_pred: predicted labels.
    """
    print("\nclassification Report:")
    print(classification_report(y_true, y_pred))


# Main function for command-line arguments
def main():
    parser = argparse.ArgumentParser(description="Train or Test the 3D Digits Classification Model")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # Training command
    train_parser = subparsers.add_parser("train", help="Train the model on the provided data.")
    train_parser.add_argument("--epochs", type=int, default=250, help="Number of epochs for training. (default: 250)")
    train_parser.add_argument("--batch_size", type=int, default=32, help="Batch size for training. (default: 32)")
    train_parser.add_argument("--save_model", type=str, default="trained_model", help="Path to save the trained model (no extension). (default: trained_model)")
    train_parser.add_argument("--max_sequence_length", type=int, default=200, help="Maximum sequence length for preprocessing. (default: 200)")
    train_parser.add_argument("--training_data_path", type=str, default="training_data", help="Path to the training data folder. (default: training_data)")

    # Testing command digit_classify
    test_parser = subparsers.add_parser("digit_classify", help="Test the model on a provided sample.")
    test_parser.add_argument("--model_path", type=str, default="trained_model.keras", help="File path to load the trained model. (default: trained_model)")
    test_parser.add_argument("--sample_path", type=str, required=True, help="File path to the test sample (CSV format).")
    test_parser.add_argument("--max_sequence_length", type=int, default=200, help="Maximum sequence length for preprocessing. (default: 200)")
    test_parser.add_argument("--verbose", type=int, default=0, help="Print out the debugging value")

    # Evaluation command
    eval_parser = subparsers.add_parser("evaluate", help="Evaluate the model on the test dataset.")
    eval_parser.add_argument("--model_path", type=str, default="trained_model",help="File path to load the trained model. (default: trained_model)")
    eval_parser.add_argument("--max_sequence_length", type=int, default=200, help="Maximum sequence length for preprocessing. (default: 200)")

    # Visualization command
    vis_parser = subparsers.add_parser("visualize", help="Visualize training and validation metrics.")
    vis_parser.add_argument("--model_name", default="trained_model" ,type=str, help="Name of the model (without extension) to visualize training metrics. (default: trained_model)")

    # Prediction command
    predict_parser = subparsers.add_parser("predict", help="Run predictions on a folder of samples.")
    predict_parser.add_argument("--model_path", type=str, default="trained_model", help="File path to load the trained model. (default: trained_model)")
    predict_parser.add_argument("--folder_path", type=str, required=True, help="Folder containing test sample files (CSV format).")
    predict_parser.add_argument("--max_sequence_length", type=int, default=200, help="Maximum sequence length for preprocessing. (default: 200)")

    # Cleanup command
    clean_parser = subparsers.add_parser("clean", help="Delete specific or all model files.")
    clean_parser.add_argument("--model_path", type=str,help="Base name of the model file to delete (optional, no extension). If not provided, all `.keras` model files will be deleted.")

    args = parser.parse_args()


    if args.command == "train":
        run_training(epochs=args.epochs, batch_size=args.batch_size, save_model_path=args.save_model,max_sequence_length=args.max_sequence_length, training_data_path=args.training_data_path)
    elif args.command == "digit_classify":
         run_test(sample_path=args.sample_path,model_path=args.model_path, max_sequence_length=args.max_sequence_length, verbose = args.verbose)
    elif args.command == "evaluate":
        run_evaluation(model_path=args.model_path,max_sequence_length=args.max_sequence_length)
    elif args.command == "visualize":
        run_visualization(model_name=args.model_name)
    elif args.command == "predict":
        run_prediction(folder_path=args.folder_path,max_sequence_length=args.max_sequence_length)
    elif args.command == "clean":
        run_cleanup(model_path=args.model_path)


# Entry point
if __name__ == "__main__":
    main()